package Section_2_Introduction;

public class Variable {
    public static void main(String[] args) {
        int age = 25;
        String name = "Ludo";
        String town = "Bracknell";

        final int SOME_NUM = 150;

        System.out.println(name + " is " + age);
        System.out.print("He lives in " + town);


    }

}
