package Section_2_Introduction;

public class Conversion {

    public static void main(String[] args) {
        double myDouble = 1.34;
        float myFloat = 1.34f;
        double yourDouble = myFloat + myFloat;

        System.out.print(yourDouble);
    }
}
