package Section_2_Introduction;

public class Comments {
    public static void main(String[] something) {
        //this is a single line comment
        System.out.print("this is not a comment");
    /*
    here
    is
    a
    comment
    with
    multiple
    lines
     */
    }
}
